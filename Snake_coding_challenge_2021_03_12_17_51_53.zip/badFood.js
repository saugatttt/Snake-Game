let badFood;
let x2;
let y2;
class BadFood{
  
  constructor(){
    this.x = x;
    this.y = y;
    
  }
  
  location(){
    
    let x = floor(random(w));
  let y = floor(random(h));
  badFood = createVector(x, y);
   // print(x2);
  }
}